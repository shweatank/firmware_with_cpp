#include <stdint.h>

// Base addresses for peripheral registers
#define RCC_BASE        0x40023800U  // Reset Clock Counter base address
#define GPIOG_BASE      0x40021800U  // GPIOG base address

// RCC register offsets
#define RCC_AHB1ENR     (*(volatile uint32_t *)(RCC_BASE + 0x30U))

// GPIOG register offsets
#define GPIOG_MODER     (*(volatile uint32_t *)(GPIOG_BASE + 0x00U))
#define GPIOG_ODR       (*(volatile uint32_t *)(GPIOG_BASE + 0x14U))

// Pin and delay constants
#define GPIOG_PIN13     13U
#define GPIOG_PIN14     14U// Pin number for PG13 (onboard LED)
#define DELAY_COUNT     500000U     // Delay loop count

// Simple delay function
void delay(volatile uint32_t count) {
    while (count--) {
        __asm__("NOP"); // Prevent compiler optimization with correct assembly syntax
    }
}

int main(void) {
    // 1. Enable clock for GPIOG (set bit 6 in RCC_AHB1ENR)
    RCC_AHB1ENR |= (1U << 6);

    // 2. Set PG13 as output (MODER[27:26] = 0b01 for pin 13)
    GPIOG_MODER &= ~(0b11U << (GPIOG_PIN13 * 2U)); // Clear mode bits for PG13
    GPIOG_MODER |= (0b01U << (GPIOG_PIN13 * 2U));  // Set PG13 to output mode
    GPIOG_MODER &= ~(0b11U << (GPIOG_PIN14 * 2U)); // Clear mode bits for PG13
    GPIOG_MODER |= (0b01U << (GPIOG_PIN14 * 2U));  // Set PG13 to output mode

    // 3. Blink onboard LED (PG13)
    while (1) {
        GPIOG_ODR ^= (1U << GPIOG_PIN13); // Toggle PG13
        GPIOG_ODR ^= (1U << GPIOG_PIN14); // Toggle PG14
        delay(DELAY_COUNT);              // Simple delay
    }

    return 0; // Code should never reach this point
}
