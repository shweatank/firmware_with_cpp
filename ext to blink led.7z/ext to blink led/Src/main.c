#include <stdint.h>

// Base addresses for peripherals
#define RCC_BASE         0x40023800
#define GPIOG_BASE       0x40021800
#define GPIOA_BASE       0x40020000
#define SYSCFG_BASE      0x40013800
#define EXTI_BASE        0x40013C00
#define NVIC_ISER0       0xE000E100

// RCC Registers
#define RCC_AHB1ENR      (*(volatile uint32_t *)(RCC_BASE + 0x30))
#define RCC_APB2ENR      (*(volatile uint32_t *)(RCC_BASE + 0x44))

// GPIO Registers
#define GPIOG_MODER      (*(volatile uint32_t *)(GPIOG_BASE + 0x00))
#define GPIOG_ODR        (*(volatile uint32_t *)(GPIOG_BASE + 0x14))
#define GPIOA_MODER      (*(volatile uint32_t *)(GPIOA_BASE + 0x00))
#define GPIOA_PUPDR      (*(volatile uint32_t *)(GPIOA_BASE + 0x0C))

// SYSCFG Registers
#define SYSCFG_EXTICR1   (*(volatile uint32_t *)(SYSCFG_BASE + 0x08))

// EXTI Registers
#define EXTI_IMR         (*(volatile uint32_t *)(EXTI_BASE + 0x00))
#define EXTI_RTSR        (*(volatile uint32_t *)(EXTI_BASE + 0x08))
#define EXTI_FTSR        (*(volatile uint32_t *)(EXTI_BASE + 0x0C))
#define EXTI_PR          (*(volatile uint32_t *)(EXTI_BASE + 0x14))

// NVIC Registers
#define NVIC_ISER0_REG   (*(volatile uint32_t *)(NVIC_ISER0))

void EXTI0_IRQHandler(void) {
    if (EXTI_PR & (1 << 0)) { // Check if EXTI0 interrupt is pending
        EXTI_PR |=(1 << 0);  // Clear the pending flag
        GPIOG_ODR ^= (1 << 13); // Toggle PG13 (LED)
    }
}

void EXTI_Config() {
    // 1. Enable GPIOA and GPIOG clock in RCC_AHB1ENR
    RCC_AHB1ENR |= (1 << 0);  // Enable GPIOA clock
    RCC_AHB1ENR |= (1 << 6);  // Enable GPIOG clock

    // 2. Configure PA0 as input in GPIOA_MODER
    GPIOA_MODER &= ~(3 << (0 * 2)); // Clear bits [1:0] for PA0 (set to input mode)

    // 3. Configure pull-down resistor for PA0
    GPIOA_PUPDR &= ~(3 << (0 * 2)); // Clear pull-up/pull-down configuration
    GPIOA_PUPDR |= (2 << (0 * 2));  // Set pull-down for PA0

    // 4. Configure PG13 as output in GPIOG_MODER
    GPIOG_MODER &= ~(3 << (13 * 2)); // Clear bits [27:26] for PG13
    GPIOG_MODER |= (1 << (13 * 2));  // Set bits [27:26] to 01 (output mode)

    // 5. Enable SYSCFG clock in RCC_APB2ENR
    RCC_APB2ENR |= (1 << 14); // Enable SYSCFG clock

    // 6. Map PA0 to EXTI0 in SYSCFG_EXTICR1
    SYSCFG_EXTICR1 &= ~(0xF << 0); // Clear bits [3:0] (default maps PA0 to EXTI0)

    // 7. Configure EXTI0 for rising edge trigger
    EXTI_IMR |= (1 << 0);  // Unmask EXTI0 (enable interrupt)
    EXTI_RTSR |= (1 << 0); // Enable rising edge trigger
    EXTI_FTSR &= ~(1 << 0); // Disable falling edge trigger

    // 8. Enable EXTI0 interrupt in NVIC
    NVIC_ISER0_REG |= (1 << 6); // Enable EXTI0 interrupt (IRQ6)
}

int main() {
    EXTI_Config();

    // TO Turn off LED initially
   // GPIOG_ODR &= ~(1 << 13);

    while (1) {
        // Main loop can perform other tasks
    }
}
