/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "../Inc/main.hpp"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <iostream>
#include<vector>
#include<stdio.h>
#include<string.h>
using namespace std;
class Shape {
public:
    virtual double calculateArea() const = 0;
    virtual ~Shape() {}
};

class Circle : public Shape {
private:
    double radius;

public:
    Circle(double r) : radius(r) {}
    double calculateArea() const override {
        return 3.14 * radius * radius;
    }
};
class Rectangle : public Shape {
private:
    double length, breadth;

public:
    Rectangle(double l, double b) : length(l), breadth(b) {}
    double calculateArea() const override {
        return length * breadth;
    }
};
class Triangle : public Shape {
private:
    double len ,base, height;

public:
    Triangle(double l,double b, double h) : len(l) ,base(b), height(h) {}
    double calculateArea() const override {
        return 0.5 * base * height;
    }
};
//void displayArea(const Shape* shape) {
//    cout<<"The area is:"<<shape->calculateArea()<<endl;
//}



/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */
uint8_t rxbuff[3];
/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {

	    /* MCU Initialization Code */
	    HAL_Init();
	    SystemClock_Config();
	    MX_GPIO_Init();
	    MX_USART1_UART_Init();

	    uint8_t rxbuff[10] = {0};  // Buffer for UART input
	    char message[100] = {0};   // Output message buffer
	    uint8_t length = 0, breadth = 0, height = 0, radius = 0;

	    HAL_UART_Transmit(&huart1, (uint8_t *)"ENTER YOUR SHAPE (1: Circle, 2: Rectangle, 3: Triangle): ",
	                      strlen("ENTER YOUR SHAPE (1: Circle, 2: Rectangle, 3: Triangle): "), 1000);
	    HAL_UART_Receive(&huart1, rxbuff, 1, 5000);  // Read user input for shape choice

	    switch (rxbuff[0]) {
	    case '1': {  // Circle
	        HAL_UART_Transmit(&huart1, (uint8_t *)"Enter radius: ", strlen("Enter radius: "), 5000);
	        memset(rxbuff, 0, sizeof(rxbuff));  // Clear buffer
	        HAL_UART_Receive(&huart1, rxbuff, 1, 5000);  // Receive radius
	        radius = rxbuff[0] - '0';

	        Circle obj(radius);  // Circle initialization
	        double circleArea = obj.calculateArea();
	        sprintf(message, "AREA OF A CIRCLE IS %.2f\n", circleArea);
	        HAL_UART_Transmit(&huart1, (uint8_t *)message, strlen(message), 5000);
	        break;
	    }

	    case '2': {  // Rectangle
	        HAL_UART_Transmit(&huart1, (uint8_t *)"Enter length and breadth: ",
	                          strlen("Enter length and breadth: "), 5000);
	        memset(rxbuff, 0, sizeof(rxbuff));  // Clear buffer
	        HAL_UART_Receive(&huart1, rxbuff, 2, 5000);  // Receive length and breadth
	        length = rxbuff[0] - '0';
	        breadth = rxbuff[1] - '0';

	        Rectangle obj1(length, breadth);  // Rectangle initialization
	        double rectArea = obj1.calculateArea();
	        sprintf(message, "AREA OF A RECTANGLE IS %.2f\n", rectArea);
	        HAL_UART_Transmit(&huart1, (uint8_t *)message, strlen(message), 5000);
	        break;
	    }

	    case '3': {  // Triangle
	        HAL_UART_Transmit(&huart1, (uint8_t *)"Enter base, height, and third side: ",
	                          strlen("Enter base, height, and third side: "), 5000);
	        memset(rxbuff, 0, sizeof(rxbuff));  // Clear buffer
	        HAL_UART_Receive(&huart1, rxbuff, 3, 5000);  // Receive base, height, and third side
	        length = rxbuff[0] - '0';  // Base
	        breadth = rxbuff[1] - '0'; // Height
	        height = rxbuff[2] - '0';  // Third side

	        Triangle obj2(length, breadth, height);  // Triangle initialization
	        double triArea = obj2.calculateArea();
	        sprintf(message, "AREA OF A TRIANGLE IS %.2f\n", triArea);
	        HAL_UART_Transmit(&huart1, (uint8_t *)message, strlen(message), 5000);
	        break;
	    }

	    default:
	        sprintf(message, "UNKNOWN SHAPE ENTERED\n");
	        HAL_UART_Transmit(&huart1, (uint8_t *)message, strlen(message), 5000);
	        break;
	    }

	    while (1) {
	        // Infinite loop
	    }
	}


//if(count==1){
//
//}
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
